<?php
class AdminBuhExportController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
    }

    public function initContent()
    {
        $this->content .= $this->renderForm();
        parent::initContent();
    }

    public function renderForm()
    {
        $this->fields_form = [
            'form' => [
                'legend' => [
                    'title' => $this->trans('Buhalterinis eksportas į Pragma', [], 'Modules.Buhexport.Admin'),
                    'icon' => 'icon-download',
                ],
                'input' => [
                    [
                        'type' => 'date',
                        'label' => $this->trans('Data nuo', [], 'Modules.Buhexport.Admin'),
                        'name' => 'date_from',
                        'required' => true,
                    ],
                    [
                        'type' => 'date',
                        'label' => $this->trans('Data iki', [], 'Modules.Buhexport.Admin'),
                        'name' => 'date_to',
                        'required' => true,
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->trans('Failo prefiksas', [], 'Modules.Buhexport.Admin'),
                        'name' => 'file_prefix',
                        'required' => false,
                        'desc' => $this->trans('Pvz.: pragma_ (bus naudojamas prieš orders_/credit_)', [], 'Modules.Buhexport.Admin'),
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->trans('Dokumento ID poslinkis', [], 'Modules.Buhexport.Admin'),
                        'name' => 'id_offset',
                        'required' => true,
                        'desc' => $this->trans('Skaičius, kuris pridedamas prie dokumento ID.', [], 'Modules.Buhexport.Admin'),
                        'suffix' => '',
                    ],
                    [
                        'type' => 'select',
                        'label' => $this->trans('Dokumento tipas', [], 'Modules.Buhexport.Admin'),
                        'name' => 'doc_type',
                        'options' => [
                            'query' => [
                                ['id' => 'invoice', 'name' => $this->trans('Sąskaitos (invoice)', [], 'Modules.Buhexport.Admin')],
                                ['id' => 'credit', 'name' => $this->trans('Kreditinės (credit slip)', [], 'Modules.Buhexport.Admin')],
                            ],
                            'id' => 'id',
                            'name' => 'name',
                        ],
                        'required' => true,
                    ],
                ],
                'submit' => [
                    'title' => $this->trans('Eksportuoti', [], 'Modules.Buhexport.Admin'),
                    'name'  => 'submitExport',
                    'class' => 'btn btn-primary',
                    'icon'  => 'process-icon-download',
                ],
            ],
        ];

        $helper = new HelperForm();
        $helper->module = $this->module;
        $helper->name_controller = $this->module->name;
        $helper->identifier = $this->identifier;
        $helper->token = Tools::getAdminTokenLite('AdminBuhExport');
        $helper->currentIndex = Context::getContext()->link->getAdminLink('AdminBuhExport');
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->default_form_language = (int)Context::getContext()->language->id;
        $helper->fields_value = [
            'date_from' => Tools::getValue('date_from', date('Y-m-01', strtotime('first day of last month'))),
            'date_to'   => Tools::getValue('date_to', date('Y-m-t', strtotime('last day of last month'))),
            'file_prefix' => Tools::getValue('file_prefix', (string)Configuration::get('BUHEXPORT_FILE_PREFIX', 'pragma_')),
            'id_offset' => Tools::getValue('id_offset', (int)Configuration::get('BUHEXPORT_ID_OFFSET', 9665000)),
            'doc_type'  => Tools::getValue('doc_type', 'invoice'),
        ];

        return $helper->generateForm([$this->fields_form]);
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submitExport')) {
            $dateFrom = Tools::getValue('date_from');
            $dateTo = Tools::getValue('date_to');
            $docType = Tools::getValue('doc_type', 'invoice');
            $filePrefix = (string)Tools::getValue('file_prefix', (string)Configuration::get('BUHEXPORT_FILE_PREFIX', 'pragma_'));
            $idOffset = (int)Tools::getValue('id_offset', (int)Configuration::get('BUHEXPORT_ID_OFFSET', 9665000));
            if ($idOffset < 0) { $idOffset = 0; }
            Configuration::updateValue('BUHEXPORT_FILE_PREFIX', $filePrefix);
            Configuration::updateValue('BUHEXPORT_ID_OFFSET', $idOffset);

            if (!$dateFrom || !$dateTo) {
                $this->errors[] = $this->trans('Prašome nurodyti datų intervalą.', [], 'Modules.Buhexport.Admin');
                return parent::postProcess();
            }

            try {
                if ($docType === 'credit') {
                    $lines = $this->buildCreditExport($dateFrom, $dateTo);
                    $filename = $filePrefix . 'credit_' . date('Ymd_His') . '.txt';
                } else {
                    $lines = $this->buildInvoiceExport($dateFrom, $dateTo);
                    $filename = $filePrefix . 'orders_' . date('Ymd_His') . '.txt';
                }

                array_unshift($lines, $this->joinTsv($this->getHeaderFields()));
                $content = implode("\r\n", $lines) . "\r\n";
                $content1257 = @iconv('UTF-8', 'WINDOWS-1257//TRANSLIT', $content);
                if ($content1257 === false) {
                    $content1257 = mb_convert_encoding($content, 'WINDOWS-1257', 'UTF-8');
                }

                header('Content-Type: text/plain; charset=windows-1257');
                header('Content-Disposition: attachment; filename=' . $filename);
                header('Pragma: public');
                header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
                header('Expires: 0');
                echo $content1257;
                exit;
            } catch (Exception $e) {
                $this->errors[] = $this->trans('Eksporto klaida: ', [], 'Modules.Buhexport.Admin') . $e->getMessage();
            }
        }

        return parent::postProcess();
    }

    protected function getHeaderFields()
    {
        return [
            'dokumento_id',
            'dokumento_tipas',
            'gr_dok_pozymis',
            'dok_data',
            'sask_data',
            'dok_nr',
            'pirkejo_kodas',
            'rez',
            'sandelis',
            'koresp',
            'val_kodas',
            'val_kursas',
            'pastaba',
            'dok_suma',
            'dok_sum_valiuta',
            'pvm_sum',
            'pvm_sum_valiuta',
            'prekiu_suma',
            'prekiu_suma_valiuta',
            'transp_islaid_sum',
            'muito_islaid_suma',
            'kitu_pridetiniu',
            'projekto_kodas',
            'fr_pozymis',
        ];
    }

    protected function buildInvoiceExport($dateFrom, $dateTo)
    {
        $df = pSQL($dateFrom . ' 00:00:00');
        $dt = pSQL($dateTo . ' 23:59:59');
        $prefix = _DB_PREFIX_;
        $offset = (int)Configuration::get('BUHEXPORT_ID_OFFSET', 9665000);
        $sql = "
            SELECT o.id_order AS id, o.invoice_number AS nr, o.invoice_date AS date,
                   o.total_paid_tax_excl AS bepvm, o.total_paid_tax_incl AS supvm
            FROM {$prefix}orders o
            WHERE o.invoice_date BETWEEN '{$df}' AND '{$dt}'
              AND o.invoice_number > 0
        ";
        $rows = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);

        $lines = [];
        if (!$rows) {
            return $lines;
        }

        foreach ($rows as $row) {
            $id = (int)$row['id'] + $offset;
            $invoicePrefix = (string)Configuration::get('PS_INVOICE_PREFIX', '');
            $inv = ($invoicePrefix !== '' ? $invoicePrefix . '-' : '') . (int)$row['nr'];
            $date = $row['date'] ?: date('Y-m-d');
            $date = date('Y-m-d', strtotime($date));
            $bepvm = (float)$row['bepvm'];
            $supvm = (float)$row['supvm'];
            $pvm = $supvm - $bepvm;

            $fields = [
                $id,
                '2',
                '1',
                $date,
                $date,
                $inv,
                '1234567890',
                '',
                'Sandėlis',
                'LT pard.prek.grynais',
                '',
                '0.00',
                '',
                $this->fmt($supvm),
                '0.00',
                $this->fmt($pvm),
                '0.00',
                $this->fmt($bepvm),
                '0.00',
                '0.00',
                '0.00',
                '0.00',
                '',
                '',
            ];
            $lines[] = $this->joinTsv($fields);
        }
        return $lines;
    }

    protected function buildCreditExport($dateFrom, $dateTo)
    {
        // Kreditinių eksportas: stengiamės naudoti order_slip sumines reikšmes (jei pasiekiamos šiame PS variante)
        $df = pSQL($dateFrom . ' 00:00:00');
        $dt = pSQL($dateTo . ' 23:59:59');
        $prefix = _DB_PREFIX_;
        $offset = (int)Configuration::get('BUHEXPORT_ID_OFFSET', 9665000);

        // Bandoma apimti dažniausiai naudojamus stulpelius (total_products_tax_excl/incl). Jei jų nėra, sumažins reikšmes į 0.
        $sql = "
            SELECT os.id_order_slip AS id_slip, os.date_add AS date, os.id_order AS id_order,
                   IFNULL(os.total_products_tax_excl, 0) AS bepvm,
                   IFNULL(os.total_products_tax_incl, 0) AS supvm
            FROM {$prefix}order_slip os
            WHERE os.date_add BETWEEN '{$df}' AND '{$dt}'
        ";
        $rows = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);

        $lines = [];
        if (!$rows) {
            return $lines;
        }

        foreach ($rows as $row) {
            $id = (int)$row['id_slip'] + $offset; // Vidaus ID pagal analogiją
            $creditPrefix = (string)Configuration::get('PS_CREDIT_SLIP_PREFIX', '');
            $inv = ($creditPrefix !== '' ? $creditPrefix . '-' : '') . (int)$row['id_slip'];
            $date = $row['date'] ?: date('Y-m-d');
            $date = date('Y-m-d', strtotime($date));
            $bepvm = (float)$row['bepvm'];
            $supvm = (float)$row['supvm'];
            $pvm = $supvm - $bepvm;

            // Kreditinėse dažnai sumos turėtų būti neigiamos (grąžinimas)
            $bepvm = -1 * abs($bepvm);
            $supvm = -1 * abs($supvm);
            $pvm = -1 * abs($pvm);

            $fields = [
                $id,
                '2',
                '1',
                $date,
                $date,
                $inv,
                '1234567890',
                '',
                'Sandėlis',
                'LT pard.prek.grynais',
                '',
                '0.00',
                '',
                $this->fmt($supvm),
                '0.00',
                $this->fmt($pvm),
                '0.00',
                $this->fmt($bepvm),
                '0.00',
                '0.00',
                '0.00',
                '0.00',
                '',
                '',
            ];
            $lines[] = $this->joinTsv($fields);
        }
        return $lines;
    }

    protected function joinTsv(array $fields)
    {
        $escaped = [];
        foreach ($fields as $f) {
            $s = (string)$f;
            $s = str_replace(["\r", "\n", "\t"], ' ', $s);
            $escaped[] = $s;
        }
        return implode("\t", $escaped);
    }

    protected function fmt($number)
    {
        return number_format((float)$number, 2, '.', '');
    }
}
